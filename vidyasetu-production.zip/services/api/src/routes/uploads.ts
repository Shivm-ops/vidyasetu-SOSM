import { FastifyInstance } from "fastify";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { z } from "zod";

const s3 = new S3Client({
  region: process.env.AWS_REGION ?? "ap-south-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
});

const presignSchema = z.object({
  filename: z.string().min(1),
  contentType: z.string().min(1),
  folder: z.enum(["profiles", "content", "homework", "documents"]),
});

export async function uploadRoutes(app: FastifyInstance) {
  const authenticate = { preHandler: [app.authenticate] };

  // GET presigned URL for direct S3 upload from client
  app.post("/presign", authenticate, async (request, reply) => {
    const body = presignSchema.parse(request.body);
    const ext = body.filename.split(".").pop();
    const key = `${body.folder}/${Date.now()}-${crypto.randomUUID()}.${ext}`;

    const command = new PutObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME!,
      Key: key,
      ContentType: body.contentType,
    });

    const signedUrl = await getSignedUrl(s3, command, { expiresIn: 300 });
    const publicUrl = `${process.env.S3_CDN_URL}/${key}`;

    return reply.send({
      success: true,
      data: { uploadUrl: signedUrl, publicUrl, key },
    });
  });
}
