import fp from "fastify-plugin";
import { FastifyInstance } from "fastify";
import { prisma } from "@vidyasetu/db";

export const dbPlugin = fp(async (app: FastifyInstance) => {
  await prisma.$connect();
  app.decorate("prisma", prisma);
  app.addHook("onClose", async () => {
    await prisma.$disconnect();
  });
  app.log.info("Database connected");
});

declare module "fastify" {
  interface FastifyInstance {
    prisma: typeof prisma;
  }
}
