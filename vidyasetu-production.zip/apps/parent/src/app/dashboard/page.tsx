"use client";

import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Calendar, Award, MessageCircle, Bell } from "lucide-react";
import { api } from "@/lib/api";
import { useAuthStore } from "@/lib/store";

export default function ParentDashboard() {
  const { user } = useAuthStore();
  const parentId = user?.parent?.id;

  const { data: children, isLoading } = useQuery({
    queryKey: ["parent-children", parentId],
    queryFn: () =>
      api.get(`/parents/${parentId}/children`).then((r) => r.data.data),
    enabled: !!parentId,
  });

  const firstChild = children?.[0];

  const { data: childSummary } = useQuery({
    queryKey: ["child-summary", firstChild?.student?.id],
    queryFn: () =>
      api
        .get(`/parents/${parentId}/child/${firstChild?.student?.id}/summary`)
        .then((r) => r.data.data),
    enabled: !!firstChild?.student?.id,
  });

  if (isLoading) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="animate-spin h-8 w-8 rounded-full border-4 border-brand-500 border-t-transparent" />
    </div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-peacock-500 to-peacock-600 px-4 pt-safe-top pb-6 text-white">
        <div className="mx-auto max-w-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-peacock-100 text-sm">नमस्कार,</p>
              <h1 className="text-2xl font-bold font-marathi">
                {user?.firstNameMarathi ?? user?.firstName} 🙏
              </h1>
            </div>
            <button className="relative rounded-full p-2 bg-white/20">
              <Bell className="h-5 w-5" />
            </button>
          </div>

          {/* Child selector */}
          {children?.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {children.map((link: any) => (
                <button
                  key={link.student.id}
                  className="flex-shrink-0 rounded-full bg-white/20 px-3 py-1.5 text-sm font-marathi"
                >
                  {link.student.user.firstNameMarathi ?? link.student.user.firstName}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mx-auto max-w-xl px-4 py-6 space-y-4">
        {/* Student card */}
        {firstChild && (
          <div className="rounded-2xl bg-white shadow-sm overflow-hidden">
            <div className="bg-gradient-to-r from-brand-50 to-peacock-50 p-4 flex items-center gap-4">
              <div className="h-16 w-16 rounded-full bg-brand-100 flex items-center justify-center text-2xl font-bold text-brand-600">
                {(firstChild.student.user.firstNameMarathi ?? firstChild.student.user.firstName)?.[0]}
              </div>
              <div>
                <p className="text-lg font-bold text-gray-900 font-marathi">
                  {firstChild.student.user.firstNameMarathi ?? firstChild.student.user.firstName}{" "}
                  {firstChild.student.user.lastNameMarathi ?? firstChild.student.user.lastName}
                </p>
                <p className="text-sm text-gray-500">
                  इयत्ता {firstChild.student.grade} •{" "}
                  {firstChild.student.user.school?.nameMarathi ?? firstChild.student.user.school?.name}
                </p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="rounded-full bg-brand-100 px-2 py-0.5 text-xs text-brand-700 font-medium">
                    स्तर {firstChild.student.learningPoints?.level ?? 1}
                  </span>
                  <span className="text-xs text-gray-500">
                    {firstChild.student.learningPoints?.totalPoints ?? 0} पॉइंट्स
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Attendance */}
        {childSummary?.attendance && (
          <div className="rounded-xl bg-white shadow-sm p-4">
            <h3 className="font-semibold text-gray-800 font-marathi flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-green-500" />
              उपस्थिती सारांश
            </h3>
            <div className="flex items-center gap-4">
              <div className="relative h-20 w-20">
                <svg className="progress-ring" height="80" width="80">
                  <circle stroke="#e5e7eb" strokeWidth="8" fill="transparent" r="32" cx="40" cy="40" />
                  <circle
                    stroke="#22c55e" strokeWidth="8"
                    strokeDasharray={`${2 * Math.PI * 32 * childSummary.attendance.percentage / 100} ${2 * Math.PI * 32}`}
                    strokeLinecap="round" fill="transparent" r="32" cx="40" cy="40"
                    style={{ transition: "stroke-dasharray 0.5s" }}
                  />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-lg font-bold text-gray-800">
                  {childSummary.attendance.percentage}%
                </span>
              </div>
              <div className="flex-1 grid grid-cols-2 gap-2">
                <div className="text-center">
                  <p className="text-xl font-bold text-green-600">{childSummary.attendance.present}</p>
                  <p className="text-xs text-gray-500 font-marathi">उपस्थित दिवस</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-red-500">
                    {childSummary.attendance.total - childSummary.attendance.present}
                  </p>
                  <p className="text-xs text-gray-500 font-marathi">अनुपस्थित दिवस</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recent Assessments */}
        {childSummary?.recentAssessments?.length > 0 && (
          <div className="rounded-xl bg-white shadow-sm p-4">
            <h3 className="font-semibold text-gray-800 font-marathi flex items-center gap-2 mb-3">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              अलीकडील परीक्षा
            </h3>
            <div className="space-y-2">
              {childSummary.recentAssessments.slice(0, 4).map((a: any) => (
                <div key={a.id} className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2">
                  <div>
                    <p className="text-sm font-medium text-gray-800">{a.assessment?.title}</p>
                    <p className="text-xs text-gray-400">{a.assessment?.subjectCode}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-bold ${a.isPassed ? "text-green-600" : "text-red-500"}`}>
                      {Math.round(a.percentScore ?? 0)}%
                    </p>
                    <p className="text-xs text-gray-400">{a.isPassed ? "✅ उत्तीर्ण" : "❌ अनुत्तीर्ण"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Mood */}
        {childSummary?.moodHistory?.length > 0 && (
          <div className="rounded-xl bg-white shadow-sm p-4">
            <h3 className="font-semibold text-gray-800 font-marathi mb-3">
              मुलाची भावनिक स्थिती (अलीकडील)
            </h3>
            <div className="flex gap-2">
              {childSummary.moodHistory.slice(0, 7).map((m: any, i: number) => {
                const moodEmojis: Record<string, string> = {
                  VERY_HAPPY: "😄", HAPPY: "😊", NEUTRAL: "😐",
                  SAD: "😢", ANXIOUS: "😰", TIRED: "😴", EXCITED: "🤩",
                };
                return (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <span className="text-xl">{moodEmojis[m.mood] ?? "😐"}</span>
                    <span className="text-[9px] text-gray-400">
                      {new Date(m.createdAt).getDate()}/{new Date(m.createdAt).getMonth() + 1}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Contact Teacher */}
        <button className="w-full flex items-center justify-center gap-2 rounded-xl border-2 border-peacock-500 py-3 text-peacock-600 font-semibold hover:bg-peacock-50 transition-colors font-marathi">
          <MessageCircle className="h-5 w-5" />
          शिक्षकांशी बोला
        </button>
      </div>
    </div>
  );
}
