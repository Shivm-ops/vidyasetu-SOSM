"use client";

import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Users, CheckSquare, BookOpen, BarChart3, Bell,
  Sparkles, ClipboardList, TrendingUp, AlertCircle
} from "lucide-react";
import { api } from "@/lib/api";
import { useAuthStore } from "@/lib/store";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

export default function TeacherDashboard() {
  const { user } = useAuthStore();
  const teacherId = user?.teacher?.id;

  const { data: dashboard } = useQuery({
    queryKey: ["teacher-dashboard", teacherId],
    queryFn: () =>
      api.get(`/teachers/${teacherId}/dashboard`).then((r) => r.data.data),
    enabled: !!teacherId,
  });

  const { data: analytics } = useQuery({
    queryKey: ["teacher-analytics", teacherId],
    queryFn: () =>
      api.get(`/teachers/${teacherId}/analytics`).then((r) => r.data.data),
    enabled: !!teacherId,
  });

  const teacher = dashboard?.teacher;
  const sections = dashboard?.sections ?? [];

  const statsCards = [
    {
      label: "एकूण विद्यार्थी",
      value: analytics?.totalStudents ?? 0,
      icon: Users,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      label: "सरासरी उपस्थिती",
      value: `${analytics?.avgAttendance ?? 0}%`,
      icon: CheckSquare,
      color: "text-green-600",
      bg: "bg-green-50",
    },
    {
      label: "पूर्ण केलेले धडे",
      value: analytics?.lessonCompletions ?? 0,
      icon: BookOpen,
      color: "text-orange-600",
      bg: "bg-orange-50",
    },
    {
      label: "सरासरी गुण",
      value: `${analytics?.avgScore ?? 0}%`,
      icon: BarChart3,
      color: "text-purple-600",
      bg: "bg-purple-50",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900 font-marathi">
              नमस्कार, {teacher?.user.firstNameMarathi ?? teacher?.user.firstName} सर/मॅडम 🙏
            </h1>
            <p className="text-sm text-gray-500">
              {teacher?.user.school?.nameMarathi ?? teacher?.user.school?.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg hover:bg-gray-100">
              <Bell className="h-5 w-5 text-gray-600" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {statsCards.map((stat) => (
            <div key={stat.label} className="rounded-xl bg-white p-4 shadow-sm">
              <div className={`inline-flex h-10 w-10 items-center justify-center rounded-lg ${stat.bg} mb-3`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500 font-marathi">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
            जलद कृती
          </h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {quickActions.map((action) => (
              <a
                key={action.label}
                href={action.href}
                className="flex flex-col items-center gap-2 rounded-xl bg-white p-4 text-center shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all"
              >
                <div
                  className="flex h-12 w-12 items-center justify-center rounded-xl text-2xl"
                  style={{ backgroundColor: action.bg }}
                >
                  {action.icon}
                </div>
                <p className="text-sm font-medium text-gray-700 font-marathi">{action.label}</p>
              </a>
            ))}
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* My Classes */}
          <div className="rounded-xl bg-white shadow-sm p-5">
            <h2 className="font-semibold text-gray-800 font-marathi mb-4 flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-brand-500" />
              माझे वर्ग
            </h2>
            <div className="space-y-3">
              {sections.length === 0 && (
                <p className="text-sm text-gray-400 font-marathi">कोणतेही वर्ग नाहीत</p>
              )}
              {sections.map((section: any) => (
                <div
                  key={section.id}
                  className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2.5"
                >
                  <div>
                    <p className="font-medium text-sm text-gray-800">
                      इयत्ता {section.classGrade?.grade} - {section.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {section._count?.enrollments ?? 0} विद्यार्थी
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`/attendance?sectionId=${section.id}`}
                      className="rounded-lg bg-green-100 px-2.5 py-1 text-xs text-green-700 font-medium hover:bg-green-200"
                    >
                      हजेरी
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Assistant */}
          <div className="rounded-xl bg-gradient-to-br from-brand-500 to-brand-600 p-5 text-white">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-5 w-5" />
              <h2 className="font-semibold font-marathi">AI शिक्षक सहाय्यक</h2>
            </div>
            <p className="text-brand-100 text-sm mb-4 font-marathi">
              धडा योजना, प्रश्नपत्रिका, उपक्रम — AI च्या मदतीने मिनिटांत तयार करा
            </p>
            <div className="grid grid-cols-2 gap-2">
              {aiTools.map((tool) => (
                <a
                  key={tool.label}
                  href={tool.href}
                  className="flex items-center gap-2 rounded-lg bg-white/15 px-3 py-2 text-sm hover:bg-white/25 transition-colors"
                >
                  <span>{tool.icon}</span>
                  <span className="font-marathi">{tool.label}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Pending Homework */}
        <div className="rounded-xl bg-white shadow-sm p-5">
          <h2 className="font-semibold text-gray-800 font-marathi mb-4 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-amber-500" />
            प्रलंबित गृहपाठ सादरणी
          </h2>
          <p className="text-sm text-gray-500 font-marathi">
            {dashboard?.pendingHomework ?? 0} गृहपाठ पडताळणी प्रलंबित आहेत
          </p>
          <a href="/homework" className="mt-2 inline-block text-sm text-brand-500 hover:underline">
            गृहपाठ पहा →
          </a>
        </div>
      </div>
    </div>
  );
}

const quickActions = [
  { label: "हजेरी घ्या", icon: "✅", bg: "#F0FDF4", href: "/attendance" },
  { label: "प्रश्नपत्रिका तयार करा", icon: "📝", bg: "#FFF7ED", href: "/assessments/create" },
  { label: "गृहपाठ द्या", icon: "📚", bg: "#EFF6FF", href: "/homework/create" },
  { label: "प्रगती अहवाल", icon: "📊", bg: "#FDF4FF", href: "/reports" },
];

const aiTools = [
  { label: "धडा योजना", icon: "📋", href: "/ai/lesson-plan" },
  { label: "प्रश्न निर्माण", icon: "❓", href: "/ai/quiz" },
  { label: "उपक्रम", icon: "🎨", href: "/ai/activity" },
  { label: "उपचारात्मक", icon: "🔧", href: "/ai/remedial" },
];
