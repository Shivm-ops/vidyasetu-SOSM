"use client";

import { useQuery } from "@tanstack/react-query";
import { BookOpen, Flame, Star, TrendingUp, Clock, Award, Calendar } from "lucide-react";
import { api } from "@/lib/api";
import { useAuthStore } from "@/lib/store";
import { SubjectCard } from "@/components/student/SubjectCard";
import { ProgressRing } from "@/components/ui/ProgressRing";
import { MoodCheckIn } from "@/components/student/MoodCheckIn";
import { AITutorButton } from "@/components/student/AITutorButton";

export default function StudentDashboard() {
  const { user } = useAuthStore();
  const studentId = user?.student?.id;

  const { data: dashboard, isLoading } = useQuery({
    queryKey: ["student-dashboard", studentId],
    queryFn: () => api.get(`/students/${studentId}/dashboard`).then((r) => r.data.data),
    enabled: !!studentId,
  });

  const { data: subjectsData } = useQuery({
    queryKey: ["subjects", user?.student?.grade],
    queryFn: () =>
      api
        .get("/curriculum/subjects", { params: { grade: user?.student?.grade } })
        .then((r) => r.data.data),
    enabled: !!user?.student?.grade,
  });

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  const student = dashboard?.student;
  const points = student?.learningPoints;
  const greeting = getGreeting();

  return (
    <div className="min-h-screen bg-gray-50 pb-24 md:pb-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-brand-500 to-brand-600 px-4 pt-safe-top pb-6 text-white">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-brand-100 text-sm">{greeting}</p>
              <h1 className="text-2xl font-bold font-marathi">
                {student?.user.firstNameMarathi ?? student?.user.firstName} 👋
              </h1>
              <p className="text-brand-200 text-sm mt-0.5">
                इयत्ता {student?.grade} • {student?.user.school?.nameMarathi ?? student?.user.school?.name}
              </p>
            </div>
            <div className="flex flex-col items-center">
              <ProgressRing
                value={dashboard?.attendancePercentage ?? 0}
                size={60}
                color="#fed7aa"
                label={`${dashboard?.attendancePercentage ?? 0}%`}
              />
              <p className="text-xs text-brand-200 mt-1">उपस्थिती</p>
            </div>
          </div>

          {/* Points & Level */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl bg-white/15 p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-yellow-300">
                <Star className="h-4 w-4" />
                <span className="font-bold">{points?.totalPoints ?? 0}</span>
              </div>
              <p className="text-xs text-brand-200">पॉइंट्स</p>
            </div>
            <div className="rounded-xl bg-white/15 p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-orange-300">
                <Flame className="h-4 w-4" />
                <span className="font-bold">
                  {dashboard?.student?.progress?.[0]?.streakDays ?? 0}
                </span>
              </div>
              <p className="text-xs text-brand-200">दिवस</p>
            </div>
            <div className="rounded-xl bg-white/15 p-3 text-center">
              <div className="flex items-center justify-center gap-1">
                <span className="font-bold">{points?.level ?? 1}</span>
              </div>
              <p className="text-xs text-brand-200 font-marathi">{points?.levelName ?? "नवशिक्या"}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-2xl px-4 py-6 space-y-6">
        {/* Mood Check-in */}
        <MoodCheckIn studentId={studentId!} />

        {/* AI Tutor */}
        <AITutorButton grade={user?.student?.grade ?? 5} />

        {/* Continue Learning */}
        {dashboard?.recentLessons?.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-gray-800 font-marathi flex items-center gap-2">
                <Clock className="h-4 w-4 text-brand-500" />
                शिकणे सुरू ठेवा
              </h2>
              <a href="/learn" className="text-sm text-brand-500">सर्व पहा →</a>
            </div>
            <div className="space-y-2">
              {dashboard.recentLessons.slice(0, 2).map((item: any) => (
                <a
                  key={item.lesson.id}
                  href={`/learn/${item.lesson.id}`}
                  className="flex items-center gap-3 rounded-xl bg-white p-3 shadow-sm card-lift"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-100 text-brand-600">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-800 text-sm truncate font-marathi">
                      {item.lesson.titleMarathi ?? item.lesson.title}
                    </p>
                    <p className="text-xs text-gray-400">
                      {item.lesson.chapter?.subject?.nameMarathi ?? item.lesson.chapter?.subject?.name}
                    </p>
                  </div>
                  <div className="text-xs text-gray-400">→</div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Subjects */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-gray-800 font-marathi flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-peacock-500" />
              विषय
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {(subjectsData ?? []).slice(0, 6).map((subject: any) => (
              <SubjectCard key={subject.id} subject={subject} />
            ))}
          </div>
        </section>

        {/* Upcoming Assessments */}
        {dashboard?.upcomingAssessments?.length > 0 && (
          <section>
            <h2 className="font-semibold text-gray-800 font-marathi flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-earth-500" />
              आगामी परीक्षा
            </h2>
            <div className="space-y-2">
              {dashboard.upcomingAssessments.map((a: any) => (
                <div
                  key={a.id}
                  className="flex items-center justify-between rounded-xl bg-white p-3 shadow-sm"
                >
                  <div>
                    <p className="font-medium text-sm text-gray-800">{a.title}</p>
                    <p className="text-xs text-gray-400">{a.subjectCode} • {a.totalMarks} गुण</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-medium text-brand-600">
                      {a.startTime
                        ? new Date(a.startTime).toLocaleDateString("mr-IN")
                        : "तारीख TBD"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Badges */}
        {dashboard?.student?.badges?.length > 0 && (
          <section>
            <h2 className="font-semibold text-gray-800 font-marathi flex items-center gap-2 mb-3">
              <Award className="h-4 w-4 text-yellow-500" />
              माझे बॅज
            </h2>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {dashboard.student.badges.map((sb: any) => (
                <div
                  key={sb.id}
                  className="flex-shrink-0 flex flex-col items-center gap-1"
                  title={sb.badge.description}
                >
                  <div className="h-14 w-14 rounded-full bg-yellow-50 border-2 border-yellow-200 flex items-center justify-center text-2xl">
                    {sb.badge.iconUrl ? (
                      <img src={sb.badge.iconUrl} alt={sb.badge.name} className="h-8 w-8" />
                    ) : "🏆"}
                  </div>
                  <p className="text-xs text-center text-gray-500 max-w-14 truncate font-marathi">
                    {sb.badge.nameMarathi ?? sb.badge.name}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "सुप्रभात! 🌅";
  if (hour < 17) return "शुभ दुपार! ☀️";
  return "शुभ संध्याकाळ! 🌙";
}

function DashboardSkeleton() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-brand-500 h-40 animate-pulse" />
      <div className="p-4 space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-24 rounded-xl shimmer" />
        ))}
      </div>
    </div>
  );
}
